'use client';
import BusinessSetup from '../../../../components/business/BusinessSetup';
export default function Page(){return <BusinessSetup type='dentist_doctor'/>}
