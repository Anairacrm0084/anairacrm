'use client';
import BusinessLanding from '../../../../components/business/BusinessLanding';
export default function Page(){return <BusinessLanding type='real_estate'/>}
