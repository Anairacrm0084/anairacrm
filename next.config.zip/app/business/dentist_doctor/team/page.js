'use client';
import BusinessModule from '../../../../components/business/BusinessModule';
export default function Page(){return <BusinessModule type='dentist_doctor' moduleKey='team'/>}
